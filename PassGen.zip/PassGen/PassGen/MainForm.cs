﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PassGen
{
    public partial class MainForm : Form
    {
        struct Lang
        {
            public String Up;
            public String Low;
        }
        struct Alphabet
        {
            public String Nums;
            public Lang Latin;
            public Lang Ciryl;
            public String Spec;
        }
        Alphabet ab = new Alphabet();
        public MainForm()
        {
            InitializeComponent();
            ab.Nums = "0123456789";
            ab.Latin.Up = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            ab.Latin.Low = "abcdefghijklmnopqrstuvwxyz";
            ab.Ciryl.Up = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЬЫЪЭЮЯ";
            ab.Ciryl.Low = "абвгдеёжзийклмнопрстуфхцчшщьыъэюя";
            ab.Spec = "!@#$%^&*()-_+=;:,./?\\|`~[]{}";
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.MinimumSize = this.Size;
        }

        private void UpdateGenAv(object sender, EventArgs e)
        {
            UpdateGenAv();
        }
        private void UpdateGenAv()
        {
            GenerateButton.Enabled = NumCheck.Checked || LatinLCheck.Checked || LatinUCheck.Checked || CirUCheck.Checked || CirylLCheck.Checked || SpecialCheck.Checked;
        }

        private void GenerateButton_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            String password = "";
            String tAb = "";
            if (NumCheck.Checked) { tAb += ab.Nums; }
            if (LatinUCheck.Checked) { tAb += ab.Latin.Up; }
            if (LatinLCheck.Checked) { tAb += ab.Latin.Low; }
            if (CirUCheck.Checked) { tAb += ab.Ciryl.Up; }
            if (CirylLCheck.Checked) { tAb += ab.Ciryl.Low; }
            if (SpecialCheck.Checked) { tAb += ab.Spec; }
            for (UInt16 i = 0; i < LengthUpDown.Value; i++)
            {
                password += tAb[rnd.Next(tAb.Length - 1)];
            }
            PasswordBox.Text = password;
        }

        private void AutoCheck_CheckedChanged(object sender, EventArgs e)
        {
            CalculateButton.Enabled = !((CheckBox)sender).Checked;
            if (((CheckBox)sender).Checked){ CalculateEntropy(); }
        }

        private void CalculateEntropy(object sender, EventArgs e)
        {
            CalculateEntropy();
        }
        private void CalculateEntropy()
        {
            Double Sentropy = 0;
            Double Aentropy = 0;
            String pass = PasswordBox.Text.Trim();
            UInt16 secureLevel = 0;
            if (pass.Length > 8) { secureLevel += 3; }
            if (CheckFor(pass, ab.Nums)) { secureLevel++; }
            if (CheckFor(pass, ab.Latin.Up)) { secureLevel++; }
            if (CheckFor(pass, ab.Latin.Low)) { secureLevel++; }
            if (CheckFor(pass, ab.Ciryl.Up)) { secureLevel++; }
            if (CheckFor(pass, ab.Ciryl.Low)) { secureLevel++; }
            if (CheckFor(pass, ab.Spec)) { secureLevel++; }
            SecurityBar.Value = secureLevel;
            if (secureLevel == 0) { SecurityStatus.Text = "Нет пароля"; }
            if (secureLevel == 1) { SecurityStatus.Text = "Очень слабый пароль"; }
            if (secureLevel > 1&&secureLevel<4) { SecurityStatus.Text = "Слабый пароль"; }
            if (secureLevel > 3&&secureLevel < 7) { SecurityStatus.Text = "Удовлетворительный пароль"; }
            if (secureLevel > 6&&secureLevel<9) { SecurityStatus.Text = "Сильный пароль"; }
            if (secureLevel == 9) { SecurityStatus.Text = "Очень сильный пароль"; }
            for(UInt16 i=0; i<pass.Length; i++)
            {
                if (i == 0) { Sentropy = 4; }
                if (i > 0 && i < 8) { Sentropy += 2; }
                if (i > 7 && i < 20) { Sentropy += 1.5; }
                if(i>19) { Sentropy++; }
            }
            if (secureLevel > 0)
            {
                Aentropy = Sentropy * (Convert.ToDouble(secureLevel)/9);
            }
            else
            {
                Aentropy = 0;
            }
            Synthetic.Text = Sentropy.ToString("##0.##") + " бит";
            Academy.Text = Aentropy.ToString("##0.##") + " бит";
        }

        private void PasswordBox_TextChanged(object sender, EventArgs e)
        {
            if (AutoCheck.Checked) { CalculateEntropy(); }
        }

        private Boolean CheckFor(String pass, String ab)
        {
            for (UInt16 i = 0; i < ab.Length; i++)
            {
                if (PasswordBox.Text.Trim().Contains(ab[i])) { return true; }
            }
            return false;
        }
    }
}
