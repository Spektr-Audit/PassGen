﻿namespace PassGen
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.WindowHolder = new System.Windows.Forms.Panel();
            this.GeneratorGroup = new System.Windows.Forms.GroupBox();
            this.GeneratorLine = new System.Windows.Forms.Label();
            this.CharGroup = new System.Windows.Forms.GroupBox();
            this.SpecialCheck = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.CirylLCheck = new System.Windows.Forms.CheckBox();
            this.CirLabel = new System.Windows.Forms.Label();
            this.CirUCheck = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.LatinLCheck = new System.Windows.Forms.CheckBox();
            this.LatinLabel = new System.Windows.Forms.Label();
            this.LatinUCheck = new System.Windows.Forms.CheckBox();
            this.CharLabel = new System.Windows.Forms.Label();
            this.NumCheck = new System.Windows.Forms.CheckBox();
            this.LengthLabel = new System.Windows.Forms.Label();
            this.LengthUpDown = new System.Windows.Forms.NumericUpDown();
            this.PasswordGroup = new System.Windows.Forms.GroupBox();
            this.EntropyGroup = new System.Windows.Forms.GroupBox();
            this.SyntethicLabel = new System.Windows.Forms.Label();
            this.EntropyLabel = new System.Windows.Forms.Label();
            this.SecurityGroup = new System.Windows.Forms.GroupBox();
            this.SecurityStatus = new System.Windows.Forms.Label();
            this.SecurityBar = new System.Windows.Forms.ProgressBar();
            this.SecurityLabel = new System.Windows.Forms.Label();
            this.CalculateGroup = new System.Windows.Forms.GroupBox();
            this.AutoCheck = new System.Windows.Forms.CheckBox();
            this.PassLine = new System.Windows.Forms.Label();
            this.PasswordLabel = new System.Windows.Forms.Label();
            this.PasswordBox = new System.Windows.Forms.TextBox();
            this.AcademyLabel = new System.Windows.Forms.Label();
            this.Synthetic = new System.Windows.Forms.Label();
            this.Academy = new System.Windows.Forms.Label();
            this.Copyright = new System.Windows.Forms.Label();
            this.CopyrightLine = new System.Windows.Forms.Label();
            this.GenerateButton = new System.Windows.Forms.Button();
            this.CalculateButton = new System.Windows.Forms.Button();
            this.WindowHolder.SuspendLayout();
            this.GeneratorGroup.SuspendLayout();
            this.CharGroup.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LengthUpDown)).BeginInit();
            this.PasswordGroup.SuspendLayout();
            this.EntropyGroup.SuspendLayout();
            this.SecurityGroup.SuspendLayout();
            this.CalculateGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // WindowHolder
            // 
            this.WindowHolder.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.WindowHolder.Controls.Add(this.GeneratorGroup);
            this.WindowHolder.Controls.Add(this.PasswordGroup);
            this.WindowHolder.Location = new System.Drawing.Point(0, 0);
            this.WindowHolder.Margin = new System.Windows.Forms.Padding(0);
            this.WindowHolder.Name = "WindowHolder";
            this.WindowHolder.Size = new System.Drawing.Size(480, 344);
            this.WindowHolder.TabIndex = 0;
            // 
            // GeneratorGroup
            // 
            this.GeneratorGroup.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GeneratorGroup.Controls.Add(this.GeneratorLine);
            this.GeneratorGroup.Controls.Add(this.CharGroup);
            this.GeneratorGroup.Controls.Add(this.LengthLabel);
            this.GeneratorGroup.Controls.Add(this.LengthUpDown);
            this.GeneratorGroup.Controls.Add(this.GenerateButton);
            this.GeneratorGroup.Location = new System.Drawing.Point(328, 0);
            this.GeneratorGroup.Margin = new System.Windows.Forms.Padding(0);
            this.GeneratorGroup.Name = "GeneratorGroup";
            this.GeneratorGroup.Padding = new System.Windows.Forms.Padding(0);
            this.GeneratorGroup.Size = new System.Drawing.Size(148, 340);
            this.GeneratorGroup.TabIndex = 1;
            this.GeneratorGroup.TabStop = false;
            // 
            // GeneratorLine
            // 
            this.GeneratorLine.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GeneratorLine.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.GeneratorLine.Location = new System.Drawing.Point(6, 40);
            this.GeneratorLine.Margin = new System.Windows.Forms.Padding(0);
            this.GeneratorLine.Name = "GeneratorLine";
            this.GeneratorLine.Size = new System.Drawing.Size(136, 2);
            this.GeneratorLine.TabIndex = 5;
            // 
            // CharGroup
            // 
            this.CharGroup.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CharGroup.Controls.Add(this.SpecialCheck);
            this.CharGroup.Controls.Add(this.groupBox5);
            this.CharGroup.Controls.Add(this.groupBox1);
            this.CharGroup.Controls.Add(this.CharLabel);
            this.CharGroup.Controls.Add(this.NumCheck);
            this.CharGroup.Location = new System.Drawing.Point(6, 66);
            this.CharGroup.Margin = new System.Windows.Forms.Padding(0);
            this.CharGroup.Name = "CharGroup";
            this.CharGroup.Padding = new System.Windows.Forms.Padding(0);
            this.CharGroup.Size = new System.Drawing.Size(136, 268);
            this.CharGroup.TabIndex = 3;
            this.CharGroup.TabStop = false;
            // 
            // SpecialCheck
            // 
            this.SpecialCheck.Checked = true;
            this.SpecialCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SpecialCheck.Location = new System.Drawing.Point(9, 242);
            this.SpecialCheck.Margin = new System.Windows.Forms.Padding(0);
            this.SpecialCheck.Name = "SpecialCheck";
            this.SpecialCheck.Size = new System.Drawing.Size(104, 20);
            this.SpecialCheck.TabIndex = 10;
            this.SpecialCheck.Text = "Спец. символы";
            this.SpecialCheck.UseVisualStyleBackColor = true;
            this.SpecialCheck.CheckedChanged += new System.EventHandler(this.UpdateGenAv);
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.CirylLCheck);
            this.groupBox5.Controls.Add(this.CirLabel);
            this.groupBox5.Controls.Add(this.CirUCheck);
            this.groupBox5.Location = new System.Drawing.Point(6, 148);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox5.Size = new System.Drawing.Size(124, 90);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            // 
            // CirylLCheck
            // 
            this.CirylLCheck.Checked = true;
            this.CirylLCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CirylLCheck.Location = new System.Drawing.Point(8, 64);
            this.CirylLCheck.Margin = new System.Windows.Forms.Padding(0);
            this.CirylLCheck.Name = "CirylLCheck";
            this.CirylLCheck.Size = new System.Drawing.Size(98, 20);
            this.CirylLCheck.TabIndex = 7;
            this.CirylLCheck.Text = "Строчные (a-z)";
            this.CirylLCheck.UseVisualStyleBackColor = true;
            this.CirylLCheck.CheckedChanged += new System.EventHandler(this.UpdateGenAv);
            // 
            // CirLabel
            // 
            this.CirLabel.Location = new System.Drawing.Point(6, 14);
            this.CirLabel.Margin = new System.Windows.Forms.Padding(0);
            this.CirLabel.Name = "CirLabel";
            this.CirLabel.Size = new System.Drawing.Size(68, 20);
            this.CirLabel.TabIndex = 6;
            this.CirLabel.Text = "Кириллица:";
            this.CirLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CirUCheck
            // 
            this.CirUCheck.Checked = true;
            this.CirUCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CirUCheck.Location = new System.Drawing.Point(9, 38);
            this.CirUCheck.Margin = new System.Windows.Forms.Padding(0);
            this.CirUCheck.Name = "CirUCheck";
            this.CirUCheck.Size = new System.Drawing.Size(110, 20);
            this.CirUCheck.TabIndex = 1;
            this.CirUCheck.Text = "Заглавные (А-Я)";
            this.CirUCheck.UseVisualStyleBackColor = true;
            this.CirUCheck.CheckedChanged += new System.EventHandler(this.UpdateGenAv);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.LatinLCheck);
            this.groupBox1.Controls.Add(this.LatinLabel);
            this.groupBox1.Controls.Add(this.LatinUCheck);
            this.groupBox1.Location = new System.Drawing.Point(6, 58);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox1.Size = new System.Drawing.Size(124, 90);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            // 
            // LatinLCheck
            // 
            this.LatinLCheck.Checked = true;
            this.LatinLCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.LatinLCheck.Location = new System.Drawing.Point(8, 64);
            this.LatinLCheck.Margin = new System.Windows.Forms.Padding(0);
            this.LatinLCheck.Name = "LatinLCheck";
            this.LatinLCheck.Size = new System.Drawing.Size(98, 20);
            this.LatinLCheck.TabIndex = 7;
            this.LatinLCheck.Text = "Строчные (a-z)";
            this.LatinLCheck.UseVisualStyleBackColor = true;
            this.LatinLCheck.CheckedChanged += new System.EventHandler(this.UpdateGenAv);
            // 
            // LatinLabel
            // 
            this.LatinLabel.Location = new System.Drawing.Point(6, 14);
            this.LatinLabel.Margin = new System.Windows.Forms.Padding(0);
            this.LatinLabel.Name = "LatinLabel";
            this.LatinLabel.Size = new System.Drawing.Size(60, 20);
            this.LatinLabel.TabIndex = 6;
            this.LatinLabel.Text = "Латиница:";
            this.LatinLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LatinUCheck
            // 
            this.LatinUCheck.Checked = true;
            this.LatinUCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.LatinUCheck.Location = new System.Drawing.Point(9, 38);
            this.LatinUCheck.Margin = new System.Windows.Forms.Padding(0);
            this.LatinUCheck.Name = "LatinUCheck";
            this.LatinUCheck.Size = new System.Drawing.Size(108, 20);
            this.LatinUCheck.TabIndex = 1;
            this.LatinUCheck.Text = "Заглавные (A-Z)";
            this.LatinUCheck.UseVisualStyleBackColor = true;
            this.LatinUCheck.CheckedChanged += new System.EventHandler(this.UpdateGenAv);
            // 
            // CharLabel
            // 
            this.CharLabel.Location = new System.Drawing.Point(6, 14);
            this.CharLabel.Margin = new System.Windows.Forms.Padding(0);
            this.CharLabel.Name = "CharLabel";
            this.CharLabel.Size = new System.Drawing.Size(94, 20);
            this.CharLabel.TabIndex = 6;
            this.CharLabel.Text = "Алфавит пароля:";
            this.CharLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // NumCheck
            // 
            this.NumCheck.Checked = true;
            this.NumCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.NumCheck.Location = new System.Drawing.Point(9, 38);
            this.NumCheck.Margin = new System.Windows.Forms.Padding(0);
            this.NumCheck.Name = "NumCheck";
            this.NumCheck.Size = new System.Drawing.Size(86, 20);
            this.NumCheck.TabIndex = 1;
            this.NumCheck.Text = "Цифры (0-9)";
            this.NumCheck.UseVisualStyleBackColor = true;
            this.NumCheck.CheckedChanged += new System.EventHandler(this.UpdateGenAv);
            // 
            // LengthLabel
            // 
            this.LengthLabel.Location = new System.Drawing.Point(6, 46);
            this.LengthLabel.Name = "LengthLabel";
            this.LengthLabel.Size = new System.Drawing.Size(82, 20);
            this.LengthLabel.TabIndex = 2;
            this.LengthLabel.Text = "Длина пароля:";
            this.LengthLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LengthUpDown
            // 
            this.LengthUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LengthUpDown.Location = new System.Drawing.Point(92, 46);
            this.LengthUpDown.Margin = new System.Windows.Forms.Padding(0);
            this.LengthUpDown.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.LengthUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.LengthUpDown.Name = "LengthUpDown";
            this.LengthUpDown.Size = new System.Drawing.Size(50, 20);
            this.LengthUpDown.TabIndex = 1;
            this.LengthUpDown.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            // 
            // PasswordGroup
            // 
            this.PasswordGroup.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PasswordGroup.Controls.Add(this.CopyrightLine);
            this.PasswordGroup.Controls.Add(this.Copyright);
            this.PasswordGroup.Controls.Add(this.EntropyGroup);
            this.PasswordGroup.Controls.Add(this.SecurityGroup);
            this.PasswordGroup.Controls.Add(this.CalculateGroup);
            this.PasswordGroup.Controls.Add(this.PassLine);
            this.PasswordGroup.Controls.Add(this.PasswordLabel);
            this.PasswordGroup.Controls.Add(this.PasswordBox);
            this.PasswordGroup.Location = new System.Drawing.Point(4, 0);
            this.PasswordGroup.Margin = new System.Windows.Forms.Padding(0);
            this.PasswordGroup.Name = "PasswordGroup";
            this.PasswordGroup.Padding = new System.Windows.Forms.Padding(0);
            this.PasswordGroup.Size = new System.Drawing.Size(320, 340);
            this.PasswordGroup.TabIndex = 0;
            this.PasswordGroup.TabStop = false;
            // 
            // EntropyGroup
            // 
            this.EntropyGroup.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.EntropyGroup.Controls.Add(this.Academy);
            this.EntropyGroup.Controls.Add(this.Synthetic);
            this.EntropyGroup.Controls.Add(this.AcademyLabel);
            this.EntropyGroup.Controls.Add(this.SyntethicLabel);
            this.EntropyGroup.Controls.Add(this.EntropyLabel);
            this.EntropyGroup.Location = new System.Drawing.Point(6, 180);
            this.EntropyGroup.Margin = new System.Windows.Forms.Padding(0);
            this.EntropyGroup.Name = "EntropyGroup";
            this.EntropyGroup.Padding = new System.Windows.Forms.Padding(0);
            this.EntropyGroup.Size = new System.Drawing.Size(308, 88);
            this.EntropyGroup.TabIndex = 11;
            this.EntropyGroup.TabStop = false;
            // 
            // SyntethicLabel
            // 
            this.SyntethicLabel.Location = new System.Drawing.Point(6, 38);
            this.SyntethicLabel.Margin = new System.Windows.Forms.Padding(0);
            this.SyntethicLabel.Name = "SyntethicLabel";
            this.SyntethicLabel.Size = new System.Drawing.Size(86, 20);
            this.SyntethicLabel.TabIndex = 7;
            this.SyntethicLabel.Text = "Синтетическая:";
            this.SyntethicLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // EntropyLabel
            // 
            this.EntropyLabel.Location = new System.Drawing.Point(6, 14);
            this.EntropyLabel.Margin = new System.Windows.Forms.Padding(0);
            this.EntropyLabel.Name = "EntropyLabel";
            this.EntropyLabel.Size = new System.Drawing.Size(58, 20);
            this.EntropyLabel.TabIndex = 6;
            this.EntropyLabel.Text = "Энтропия:";
            this.EntropyLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // SecurityGroup
            // 
            this.SecurityGroup.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SecurityGroup.Controls.Add(this.SecurityStatus);
            this.SecurityGroup.Controls.Add(this.SecurityBar);
            this.SecurityGroup.Controls.Add(this.SecurityLabel);
            this.SecurityGroup.Location = new System.Drawing.Point(6, 112);
            this.SecurityGroup.Margin = new System.Windows.Forms.Padding(0);
            this.SecurityGroup.Name = "SecurityGroup";
            this.SecurityGroup.Padding = new System.Windows.Forms.Padding(0);
            this.SecurityGroup.Size = new System.Drawing.Size(308, 68);
            this.SecurityGroup.TabIndex = 10;
            this.SecurityGroup.TabStop = false;
            // 
            // SecurityStatus
            // 
            this.SecurityStatus.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SecurityStatus.BackColor = System.Drawing.SystemColors.ControlLight;
            this.SecurityStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SecurityStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SecurityStatus.Location = new System.Drawing.Point(6, 40);
            this.SecurityStatus.Margin = new System.Windows.Forms.Padding(0);
            this.SecurityStatus.Name = "SecurityStatus";
            this.SecurityStatus.Size = new System.Drawing.Size(296, 22);
            this.SecurityStatus.TabIndex = 9;
            this.SecurityStatus.Text = "Нет пароля";
            this.SecurityStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SecurityBar
            // 
            this.SecurityBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SecurityBar.Location = new System.Drawing.Point(84, 14);
            this.SecurityBar.Margin = new System.Windows.Forms.Padding(0);
            this.SecurityBar.Maximum = 9;
            this.SecurityBar.Name = "SecurityBar";
            this.SecurityBar.Size = new System.Drawing.Size(218, 22);
            this.SecurityBar.TabIndex = 8;
            // 
            // SecurityLabel
            // 
            this.SecurityLabel.Location = new System.Drawing.Point(6, 15);
            this.SecurityLabel.Margin = new System.Windows.Forms.Padding(0);
            this.SecurityLabel.Name = "SecurityLabel";
            this.SecurityLabel.Size = new System.Drawing.Size(74, 20);
            this.SecurityLabel.TabIndex = 7;
            this.SecurityLabel.Text = "Надежность:";
            this.SecurityLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CalculateGroup
            // 
            this.CalculateGroup.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CalculateGroup.Controls.Add(this.CalculateButton);
            this.CalculateGroup.Controls.Add(this.AutoCheck);
            this.CalculateGroup.Location = new System.Drawing.Point(6, 46);
            this.CalculateGroup.Margin = new System.Windows.Forms.Padding(0);
            this.CalculateGroup.Name = "CalculateGroup";
            this.CalculateGroup.Padding = new System.Windows.Forms.Padding(0);
            this.CalculateGroup.Size = new System.Drawing.Size(308, 66);
            this.CalculateGroup.TabIndex = 9;
            this.CalculateGroup.TabStop = false;
            // 
            // AutoCheck
            // 
            this.AutoCheck.Location = new System.Drawing.Point(6, 14);
            this.AutoCheck.Margin = new System.Windows.Forms.Padding(0);
            this.AutoCheck.Name = "AutoCheck";
            this.AutoCheck.Size = new System.Drawing.Size(104, 20);
            this.AutoCheck.TabIndex = 2;
            this.AutoCheck.Text = "Автоматически";
            this.AutoCheck.UseVisualStyleBackColor = true;
            this.AutoCheck.CheckedChanged += new System.EventHandler(this.AutoCheck_CheckedChanged);
            // 
            // PassLine
            // 
            this.PassLine.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PassLine.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PassLine.Location = new System.Drawing.Point(6, 40);
            this.PassLine.Margin = new System.Windows.Forms.Padding(0);
            this.PassLine.Name = "PassLine";
            this.PassLine.Size = new System.Drawing.Size(308, 2);
            this.PassLine.TabIndex = 8;
            // 
            // PasswordLabel
            // 
            this.PasswordLabel.Location = new System.Drawing.Point(6, 15);
            this.PasswordLabel.Margin = new System.Windows.Forms.Padding(0);
            this.PasswordLabel.Name = "PasswordLabel";
            this.PasswordLabel.Size = new System.Drawing.Size(48, 20);
            this.PasswordLabel.TabIndex = 7;
            this.PasswordLabel.Text = "Пароль:";
            this.PasswordLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // PasswordBox
            // 
            this.PasswordBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PasswordBox.Location = new System.Drawing.Point(58, 15);
            this.PasswordBox.Margin = new System.Windows.Forms.Padding(0);
            this.PasswordBox.MaxLength = 128;
            this.PasswordBox.Name = "PasswordBox";
            this.PasswordBox.Size = new System.Drawing.Size(256, 20);
            this.PasswordBox.TabIndex = 1;
            this.PasswordBox.TextChanged += new System.EventHandler(this.PasswordBox_TextChanged);
            // 
            // AcademyLabel
            // 
            this.AcademyLabel.Location = new System.Drawing.Point(6, 62);
            this.AcademyLabel.Margin = new System.Windows.Forms.Padding(0);
            this.AcademyLabel.Name = "AcademyLabel";
            this.AcademyLabel.Size = new System.Drawing.Size(90, 20);
            this.AcademyLabel.TabIndex = 8;
            this.AcademyLabel.Text = "Академическая:";
            this.AcademyLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Synthetic
            // 
            this.Synthetic.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Synthetic.Location = new System.Drawing.Point(96, 38);
            this.Synthetic.Margin = new System.Windows.Forms.Padding(0);
            this.Synthetic.Name = "Synthetic";
            this.Synthetic.Size = new System.Drawing.Size(206, 20);
            this.Synthetic.TabIndex = 9;
            this.Synthetic.Text = "0 бит";
            this.Synthetic.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Academy
            // 
            this.Academy.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Academy.Location = new System.Drawing.Point(96, 62);
            this.Academy.Margin = new System.Windows.Forms.Padding(0);
            this.Academy.Name = "Academy";
            this.Academy.Size = new System.Drawing.Size(206, 20);
            this.Academy.TabIndex = 10;
            this.Academy.Text = "0 бит";
            this.Academy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Copyright
            // 
            this.Copyright.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Copyright.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Copyright.Location = new System.Drawing.Point(6, 314);
            this.Copyright.Margin = new System.Windows.Forms.Padding(0);
            this.Copyright.Name = "Copyright";
            this.Copyright.Size = new System.Drawing.Size(302, 20);
            this.Copyright.TabIndex = 11;
            this.Copyright.Text = "Интеллектуальная собственность ООО \"Спектр-Аудит\"";
            this.Copyright.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CopyrightLine
            // 
            this.CopyrightLine.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CopyrightLine.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.CopyrightLine.Location = new System.Drawing.Point(6, 308);
            this.CopyrightLine.Margin = new System.Windows.Forms.Padding(0);
            this.CopyrightLine.Name = "CopyrightLine";
            this.CopyrightLine.Size = new System.Drawing.Size(308, 2);
            this.CopyrightLine.TabIndex = 12;
            // 
            // GenerateButton
            // 
            this.GenerateButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GenerateButton.Image = global::PassGen.Graphics.Dice;
            this.GenerateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.GenerateButton.Location = new System.Drawing.Point(6, 14);
            this.GenerateButton.Margin = new System.Windows.Forms.Padding(0);
            this.GenerateButton.Name = "GenerateButton";
            this.GenerateButton.Size = new System.Drawing.Size(136, 22);
            this.GenerateButton.TabIndex = 0;
            this.GenerateButton.Text = "Генерировать";
            this.GenerateButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.GenerateButton.UseVisualStyleBackColor = true;
            this.GenerateButton.Click += new System.EventHandler(this.GenerateButton_Click);
            // 
            // CalculateButton
            // 
            this.CalculateButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CalculateButton.Image = global::PassGen.Graphics.Equal;
            this.CalculateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CalculateButton.Location = new System.Drawing.Point(6, 38);
            this.CalculateButton.Margin = new System.Windows.Forms.Padding(0);
            this.CalculateButton.Name = "CalculateButton";
            this.CalculateButton.Size = new System.Drawing.Size(296, 22);
            this.CalculateButton.TabIndex = 5;
            this.CalculateButton.Text = "Рассчитать";
            this.CalculateButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.CalculateButton.UseVisualStyleBackColor = true;
            this.CalculateButton.Click += new System.EventHandler(this.CalculateEntropy);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(480, 345);
            this.Controls.Add(this.WindowHolder);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Генератор паролей";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.WindowHolder.ResumeLayout(false);
            this.GeneratorGroup.ResumeLayout(false);
            this.CharGroup.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.LengthUpDown)).EndInit();
            this.PasswordGroup.ResumeLayout(false);
            this.PasswordGroup.PerformLayout();
            this.EntropyGroup.ResumeLayout(false);
            this.SecurityGroup.ResumeLayout(false);
            this.CalculateGroup.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel WindowHolder;
        private System.Windows.Forms.GroupBox GeneratorGroup;
        private System.Windows.Forms.GroupBox PasswordGroup;
        private System.Windows.Forms.Label GeneratorLine;
        private System.Windows.Forms.GroupBox CharGroup;
        private System.Windows.Forms.CheckBox NumCheck;
        private System.Windows.Forms.Label LengthLabel;
        private System.Windows.Forms.NumericUpDown LengthUpDown;
        private System.Windows.Forms.Button GenerateButton;
        private System.Windows.Forms.TextBox PasswordBox;
        private System.Windows.Forms.Label CharLabel;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.CheckBox CirylLCheck;
        private System.Windows.Forms.Label CirLabel;
        private System.Windows.Forms.CheckBox CirUCheck;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox LatinLCheck;
        private System.Windows.Forms.Label LatinLabel;
        private System.Windows.Forms.CheckBox LatinUCheck;
        private System.Windows.Forms.Label PasswordLabel;
        private System.Windows.Forms.Label PassLine;
        private System.Windows.Forms.CheckBox SpecialCheck;
        private System.Windows.Forms.GroupBox CalculateGroup;
        private System.Windows.Forms.Button CalculateButton;
        private System.Windows.Forms.CheckBox AutoCheck;
        private System.Windows.Forms.GroupBox SecurityGroup;
        private System.Windows.Forms.Label SecurityStatus;
        private System.Windows.Forms.ProgressBar SecurityBar;
        private System.Windows.Forms.Label SecurityLabel;
        private System.Windows.Forms.GroupBox EntropyGroup;
        private System.Windows.Forms.Label SyntethicLabel;
        private System.Windows.Forms.Label EntropyLabel;
        private System.Windows.Forms.Label Academy;
        private System.Windows.Forms.Label Synthetic;
        private System.Windows.Forms.Label AcademyLabel;
        private System.Windows.Forms.Label CopyrightLine;
        private System.Windows.Forms.Label Copyright;
    }
}

